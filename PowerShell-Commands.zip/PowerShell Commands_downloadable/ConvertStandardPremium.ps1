﻿#Convert all the managed disks of a VM from standard to premium, and vice versa
# Name of the resource group that contains the VM
$rgName = 'TetraStorageDemo'

# Name of the your virtual machine
$vmName = 'TetraVM1'

# Choose between StandardLRS and PremiumLRS based on your scenario
$storageType = 'PremiumLRS'

# Premium capable size
# Required only if converting storage from standard to premium
#$size = $vmName.HardwareProfile.VmSize
$vm = Get-AzureRmVM -Name $vmName -resourceGroupName $rgName -Verbose

# Stop and deallocate the VM before changing the size
Stop-AzureRmVM -ResourceGroupName $rgName -Name $vmName -Force -Verbose

# Change the VM size to a size that supports premium storage
# Skip this step if converting storage from premium to standard
#$vm.HardwareProfile.VmSize = $size
#Update-AzureRmVM -VM $vm -ResourceGroupName $rgName

# Get all disks in the resource group of the VM
$vmDisks = Get-AzureRmDisk -ResourceGroupName $rgName -Verbose

# For disks that belong to the selected VM, convert to standard storage
foreach ($disk in $vmDisks)
{

    if ($disk.ManagedBy -eq $vm.Id)
    {
        Write-Host "Updating disks"
        $diskUpdateConfig = New-AzureRmDiskUpdateConfig –AccountType $storageType -DiskSizeGB $disk.DiskSizeGB -Verbose
        Update-AzureRmDisk -DiskUpdate $diskUpdateConfig -ResourceGroupName $rgName `
        -DiskName $disk.Name -Verbose
    }
}
Start-AzureRmVM -ResourceGroupName $rgName -Name $vmName -Verbose
