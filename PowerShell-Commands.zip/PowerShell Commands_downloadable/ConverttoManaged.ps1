﻿
$diskConfig = New-AzureRmDiskConfig `
    -Location "East US 2" `
    -CreateOption Empty `
    -DiskSizeGB 512

$dataDisk = New-AzureRmDisk `
    -ResourceGroupName "TetraStorageDemo" `
    -DiskName "TetraVM2_Datadisk1" `
    -Disk $diskConfig

$vm = Get-AzureRmVM -ResourceGroupName "TetraStorageDemo" -Name "TetraVM2"

$vm = Add-AzureRmVMDataDisk `
    -VM $vm `
    -Name "TetraVM2_Datadisk1" `
    -CreateOption Attach `
    -ManagedDiskId $dataDisk.Id `
    -Lun 1

Update-AzureRmVM -ResourceGroupName "TetraStorageDemo" -VM $vm