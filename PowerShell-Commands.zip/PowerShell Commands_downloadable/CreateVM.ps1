﻿#Login-AzureRmAccount
$cred = Get-Credential -Message "Enter a username and password for the virtual machine."

$vnetName="TetraStorageDemo-vnet"
$subnetName="default"
$resGrpVNET="TetraStorageDemo"
$resGrp="TetraStorageDemo"
$nsgName="TetraVM1-nsg"
$vmName="TetraVM2"
$machineName="TetraVM2"
$vmSize="Standard_B4MS"
$location="East US 2"
$skuWindows="2016-Datacenter" #"2012-R2-Datacenter"
$imageName="myImage" #if exists

# Create a network configuration
$vnet = Get-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $resGrpVNET
$subnet=Get-AzureRmVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $vnet
#$nsg=Get-AzureRmNetworkSecurityGroup -Name $nsgGroup -ResourceGroupName $resGrp #if exists
<#$nsgRuleRDP = New-AzureRmNetworkSecurityRuleConfig `
    -Name $vmName"NetworkSecurityGroupRuleRDP" `
    -Protocol Tcp `
    -Direction Inbound `
    -Priority 1000 `
    -SourceAddressPrefix * `
    -SourcePortRange * `
    -DestinationAddressPrefix * `
    -DestinationPortRange 3389 `
    -Access Allow

  $nsgRuleWeb = New-AzureRmNetworkSecurityRuleConfig `
    -Name $vmName"myNetworkSecurityGroupRuleWWW"  `
    -Protocol Tcp `
    -Direction Inbound `
    -Priority 1001 `
    -SourceAddressPrefix * `
    -SourcePortRange * `
    -DestinationAddressPrefix * `
    -DestinationPortRange 80 `
    -Access Allow
   
  $nsg = New-AzureRmNetworkSecurityGroup `
    -ResourceGroupName $resGrp `
    -Location $location `
    -Name $vmName"NSG" `
    -SecurityRules $nsgRuleRDP ,$nsgRuleWeb
    #>
    $nsg=Get-AzureRmNetworkSecurityGroup -Name $nsgName -ResourceGroupName $resGrp -Verbose -ErrorAction SilentlyContinue
$publicIP = New-AzureRmPublicIpAddress `
    -ResourceGroupName $resGrp `
    -Location $location `
    -Name $vmName"IP$(Get-Random)" `
    -AllocationMethod Dynamic `
    -IdleTimeoutInMinutes 4
    
$nic = New-AzureRmNetworkInterface `
    -Name $vmName"NIC$(Get-Random)" `
    -ResourceGroupName $resGrp `
    -Location $location `
    -SubnetId $subnet.Id `
    -PublicIpAddressId $publicIP.Id `
    -NetworkSecurityGroupId $nsg.Id

# Create a virtual machine configuration
$availSet=New-AzureRmAvailabilitySet -ResourceGroupName $resGrp -Name $vmName"AvailabilitySet" -Location $location -Sku Aligned -PlatformFaultDomainCount 2 -PlatformUpdateDomainCount 5
#$availSet = Get-AzureRmAvailabilitySet -ResourceGroupName $resGrp -Name $AvailSetName -ErrorAction Ignore
$vmConfig = New-AzureRmVMConfig -VMName $vmName -VMSize $vmSize  -AvailabilitySetId $availSet.Id| ` 
Set-AzureRmVMOperatingSystem -Windows -ComputerName $machineName -Credential $cred | `
Set-AzureRmVMSourceImage -PublisherName MicrosoftWindowsServer `
    -Offer WindowsServer -Skus $skuWindows -Version latest | `
Add-AzureRmVMNetworkInterface -Id $nic.Id


New-AzureRmVM -ResourceGroupName $resGrp -Location $location -VM $vmConfig 
#>
        
<# Here is where we create a variable to store information about the image 
$vmConfig = New-AzureRmVMConfig `
    -VMName $vmName `
    -VMSize $vmSize | Set-AzureRmVMOperatingSystem -Windows `
        -ComputerName $computerName `
        -Credential $cred 
  
$image = Get-AzureRmImage `
    -ImageName $imageName `
    -ResourceGroupName $resGrp
    
# Here is where we specify that we want to create the VM from and image and provide the image ID
$vmConfig = Set-AzureRmVMSourceImage -VM $vmConfig -Id $image.Id

$vmConfig = Add-AzureRmVMNetworkInterface -VM $vmConfig -Id $nic.Id

New-AzureRmVM `
    -ResourceGroupName $resGrp `
    -Location EastUS `
    -VM $vmConfig
    #>
