﻿#Import-AzureRmContext –Path "c:\tenantscripts\myprofilenew.json" -ErrorAction Stop 

<#$rgName = "myResourceGroup"
$vmName = "myVM"
Stop-AzureRmVM -ResourceGroupName $rgName -Name $vmName -Force

ConvertTo-AzureRmVMManagedDisk -ResourceGroupName $rgName -VMName $vmName
Start-AzureRmVM -ResourceGroupName $rgName -Name $vmName
#>

$rgName = 'TetraStorageDemo'
$avSetName = 'TetraVM1AS'

$avSet = Get-AzureRmAvailabilitySet -ResourceGroupName $rgName -Name $avSetName -Verbose
Update-AzureRmAvailabilitySet -AvailabilitySet $avSet -Sku Aligned -Verbose

#$avSet.PlatformFaultDomainCount = 2
#Update-AzureRmAvailabilitySet -AvailabilitySet $avSet -Sku Aligned

$avSet = Get-AzureRmAvailabilitySet -ResourceGroupName $rgName -Name $avSetName -Verbose

foreach($vmInfo in $avSet.VirtualMachinesReferences)
{
  $vm = Get-AzureRmVM -ResourceGroupName $rgName | Where-Object {$_.Id -eq $vmInfo.id}
  Stop-AzureRmVM -ResourceGroupName $rgName -Name $vm.Name -Force -Verbose
  ConvertTo-AzureRmVMManagedDisk -ResourceGroupName $rgName -VMName $vm.Name -Verbose
  Start-AzureRmVM -ResourceGroupName $rgName -Name $vm.Name -Verbose
}